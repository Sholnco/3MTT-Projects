function App() {
  return (
    <main>
      <h1>Hello World</h1>
    </main>
  );
}

export default App;
